import icons from './icons';
import toSvg from './to-svg';
import replace from './replace';

module.exports = { icons, toSvg, replace };
